package com.example.two;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Calendar extends AppCompatActivity {
    CalendarView calendarView;
    EditText time;
    android.icu.util.Calendar calendar;
    Button back, record;
    FirebaseFirestore user;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calendar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        calendarView = findViewById(R.id.calendarView_get);
        calendar = android.icu.util.Calendar.getInstance();
        back = findViewById(R.id.backcal);
        record = findViewById(R.id.record);
        time = findViewById(R.id.editTextTime);
        user = FirebaseFirestore.getInstance();
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                wrtdata((String.valueOf(year) +"_"+ String.valueOf(month) + "_"+ String.valueOf(dayOfMonth)));
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotomenu = new Intent(Calendar.this, menu.class);
                startActivity(gotomenu);
            }
        });

        record.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                String em = intent.getStringExtra("emot");
                String eml = geteml();
                String log = getlog();
                String data = getdata();
                String tim = "нечего";
                tim = tim + time.getText().toString();
                if (tim.equals("нечего")) {
                    Toast.makeText(Calendar.this, "укажите время", Toast.LENGTH_SHORT).show();

                } else {
                    tim = tim.substring(6);
                    int lentime= tim.length();
                    if (lentime<=2){
                        Toast.makeText(Calendar.this, "Не правильно указано время", Toast.LENGTH_SHORT).show();

                    } else {
                        if (lentime==3){
                            StringBuffer strBuffer = new StringBuffer(tim);
                            tim=String.valueOf(strBuffer.insert(1, ':'));

                    }else {
                            StringBuffer strBuffer = new StringBuffer(tim);
                            tim=String.valueOf(strBuffer.insert(2, ':'));
                        }

                    if (data == null) {
                        Toast.makeText(Calendar.this, "Указалася сегодняшний день", Toast.LENGTH_SHORT).show();
                        java.util.Calendar c = java.util.Calendar.getInstance();
                        data = String.valueOf(c.get(java.util.Calendar.YEAR)) + "_" + String.valueOf(c.get(java.util.Calendar.MONTH)) + "_" + String.valueOf(c.get(java.util.Calendar.DAY_OF_MONTH));
                    }

                    Map<String, Object> tim_zag = new HashMap<>();
                   tim_zag.put("Tim", tim);
                    Map<String, Object> col = new HashMap<>();
                    col.put("emotion", em);



                    user.collection("Users").document(eml.toLowerCase()).collection("Data").document(data).collection("Time").document(tim).collection("Information").add(col).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentReference> task) {
                            Toast.makeText(Calendar.this, "Успешно", Toast.LENGTH_SHORT).show();
                        }
                    });
                    user.collection("Users").document(eml.toLowerCase()).collection("Data").document(data).collection("Time").document(tim).set(tim_zag).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            tim_zag.clear();
                        }
                    });
                }}



            }
        });
    }
    public String geteml () {
        return ((global_user) this.getApplication()).geteml();
    }

    public String getlog () {
        return ((global_user) this.getApplication()).getlog();
    }
    public void wrtdata (String data){
        ((global_user) this.getApplication()).setData(data);
    }
    public String getdata () {
        return ((global_user) this.getApplication()).getdata();
    }
}