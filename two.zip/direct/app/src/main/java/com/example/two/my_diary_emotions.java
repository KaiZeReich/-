package com.example.two;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.Firebase;
import com.google.firebase.auth.FirebaseUser;

public class my_diary_emotions extends AppCompatActivity {
    //1 столб
    Button azartbt, gnev,zlost,zavist,nedovolstvo,predvkushenie,oshidanie,rasdrashenie, beshenstvo;
    Firebase firebase;
    //2 столб
    Button simpatia,ymirotvorenie,ydivlenie,radost,voodyshivlenie,vosmushenie,presrenie,obida,yshaz;

    //3 столб
    Button likovanie,xz,strah,grust,dosada,bezmeteshnost,otvroshenie,negodovanie,doverie;
    Button accept, back;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.my_diary_emotions);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        accept=findViewById(R.id.accept);
        back=findViewById(R.id.backemot);


        //эмоции ниже обьявляем
        //1 столбец
        azartbt = findViewById(R.id.azartbt);
        gnev = findViewById(R.id.gnev);
        zlost = findViewById(R.id.zlost);
        zavist = findViewById(R.id.zavist);
        nedovolstvo = findViewById(R.id.nedovolstvo);
        predvkushenie = findViewById(R.id.predvkushenie);
        oshidanie = findViewById(R.id.oshidanie);
        rasdrashenie = findViewById(R.id.rasdrashenie);
        beshenstvo = findViewById(R.id.beshenstvo);
        //эмоции ниже обьявляем
        //2 столбец
        simpatia= findViewById(R.id.simpatia);
        ymirotvorenie= findViewById(R.id.ymirotvorenie);
        ydivlenie= findViewById(R.id.ydivlenie);
        radost= findViewById(R.id.radost);
        voodyshivlenie= findViewById(R.id.voodyshevlenie);
        vosmushenie= findViewById(R.id.vosmushenie);
        presrenie= findViewById(R.id.presrenie);
        obida= findViewById(R.id.obida);
        yshaz= findViewById(R.id.yshas);
        //эмоции ниже обьявляем
        //3 столбец
        likovanie = findViewById(R.id.likovanie);
//        xz = findViewById(R.id.beshenstvo);
        strah = findViewById(R.id.strax);
        grust = findViewById(R.id.grust);
        dosada = findViewById(R.id.dosada);
        bezmeteshnost = findViewById(R.id.bezmeteshnost);
        otvroshenie = findViewById(R.id.otvrashenie);
        negodovanie = findViewById(R.id.negodovanie);
        doverie = findViewById(R.id.doverie);










        //слушатель 1 столбца
        azartbt.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            accept.setText("Потвердить выбраную эмоцию:Азарт");

        }
        });
        gnev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Гнев");

            }
        });
        zlost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Злость");

            }
        });
        zavist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Зависть");

            }
        });
        nedovolstvo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Недовольство");

            }
        });
        predvkushenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Предвкушение");

            }
        });
        oshidanie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Ожидание");

            }
        });
        rasdrashenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Раздражение");

            }
        });
        beshenstvo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Бешенство");

            }
        });





        //слушатель 2 столбца
        simpatia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Симпатия");

            }
        });
        ymirotvorenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Умиротворение");

            }
        });
        ydivlenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Удивление");

            }
        });
        radost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Радость");

            }
        });
        voodyshivlenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Воодушевление");

            }
        });
        vosmushenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Возмущение");

            }
        });
        presrenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Презрение");

            }
        });
        obida.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Обида");

            }
        });
        yshaz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Ужас");

            }
        });






        //слушатель 3 столбца
        likovanie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Ликование");

            }
        });
//        xz.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                accept.setText("Потвердить выбраную эмоцию:Ужас");
//
//            }
//        });
        strah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Страх");

            }
        });
        grust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Грусть");

            }
        });
        dosada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Досада");

            }
        });
        bezmeteshnost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Безмятежность");

            }
        });
        otvroshenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Отвращение");

            }
        });
        negodovanie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Негодование");

            }
        });
        doverie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accept.setText("Потвердить выбраную эмоцию:Доверие");

            }
        });



        //кнопки снизу
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotomenu=new Intent(my_diary_emotions.this,menu.class);
                startActivity(gotomenu);
            }
        });
        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotocal=new Intent(my_diary_emotions.this,Calendar.class);
                String em=accept.getText().toString();
                em=em.substring(27);
                gotocal.putExtra("emot",em);
                startActivity(gotocal);
            }
        });

    }
}