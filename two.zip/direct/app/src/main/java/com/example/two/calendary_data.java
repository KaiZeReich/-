package com.example.two;

import static androidx.browser.customtabs.CustomTabsIntent.KEY_DESCRIPTION;
import static androidx.browser.trusted.sharing.ShareTarget.Params.KEY_TITLE;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class calendary_data extends AppCompatActivity {
    ListView listView;
    CalendarView calendarView;
    String x;
    ArrayAdapter<String> adapter;
    ArrayList<String> arrayList;
    Button back;
    FirebaseFirestore base_get = FirebaseFirestore.getInstance();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calendary_data);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        listView=findViewById(R.id.listview);
        back=findViewById(R.id.backcal);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotoback=new Intent(calendary_data.this,menu.class);
                startActivity(gotoback);
            }
        });
        calendarView=findViewById(R.id.calendarView_get);
        arrayList=new ArrayList<>();
        adapter=new ArrayAdapter<>(calendary_data.this, android.R.layout.simple_list_item_1,arrayList);
        String eml = geteml();
        listView.setAdapter(adapter);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                adapter.clear();
                adapter.notifyDataSetChanged();
                String data=(String.valueOf(year) +"_"+ String.valueOf(month) + "_"+ String.valueOf(dayOfMonth));
                System.out.println(eml);
                System.out.println(data);

                base_get.collection("Users").document(eml.toLowerCase()).collection("Data").document(data).collection("Time").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {

                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {

                            for (QueryDocumentSnapshot document : task.getResult()) {
                                System.out.println(document.getId() + " => " + document.getData());
                                String s = document.getId();
                                base_get.collection("Users").document(eml.toLowerCase()).collection("Data").document(data).collection("Time").document(s).collection("Information").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                        if (task.isSuccessful()) {

                                            for (QueryDocumentSnapshot document : task.getResult()) {
                                                System.out.println(document.getId() + " => " + document.getData());
                                                String em = document.getData().toString();
                                                em=em.substring(9,em.length()-1);
                                                em=s+"="+em;
                                                adapter.add(em);
                                                adapter.notifyDataSetChanged();
                                            }
                                        }
                                    }
                                });
                            }
                        }
                    }
                });
            }
        });
    }
    public String geteml() {
        return ((global_user) this.getApplication()).geteml();
    }
}